dd bs=1 skip=4 count=65536 if=firmware/HHKB410_FW_A429.hfb > firmware/firm.bin
